--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE public.messages ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.messages_id_seq;
DROP TABLE public.messages;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: bulletinboard
--

CREATE TABLE public.messages (
    title text,
    body text,
    id integer NOT NULL
);


ALTER TABLE public.messages OWNER TO bulletinboard;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: bulletinboard
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO bulletinboard;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bulletinboard
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: bulletinboard
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: bulletinboard
--

COPY public.messages (title, body, id) FROM stdin;
\.
COPY public.messages (title, body, id) FROM '$$PATH$$/3121.dat';

--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bulletinboard
--

SELECT pg_catalog.setval('public.messages_id_seq', 4, true);


--
-- PostgreSQL database dump complete
--

